#!/bin/bash

# Check if both arguments are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <variables_values> <numbers>"
    exit 1
fi

# Assign arguments to variables
VARIABLES_VALUES="$1"
NUMBERS="$2"

# Define the authorization key
AUTH_KEY="LulQZJiP1hTaDw5FCHYs3EVknRrMGW02jNzepfbId4Xy9cUKqxkzG8h9VfbxrTiPRSgeyOCZ64wJjplL"

# Define the route
ROUTE="otp"

# Construct the URL with the variables
URL="https://www.fast2sms.com/dev/bulkV2?authorization=$AUTH_KEY&variables_values=$VARIABLES_VALUES&route=$ROUTE&numbers=$NUMBERS"

# Send the GET request using curl without showing progress
response=$(curl -s -o /dev/null -w "%{http_code}" "$URL")

# Check if the request was successful
if [ "$response" -eq 200 ]; then
    echo "Success"
else
    echo "Failed"
fi
