#include "future_of_bharat.h"

int main()
{
    // write the command to send otp
    

}
