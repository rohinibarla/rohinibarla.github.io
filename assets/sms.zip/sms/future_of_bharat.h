#include <stdio.h>
#include <stdlib.h>
void send_otp(char *otp, char *number)
{
    char command[200];
    sprintf(command, "./send_sms.sh %s %s\n", otp, number);
    system(command);
}
